from flask import Flask
import sqlite3 
from flask import flash, session, render_template, request, redirect, url_for, abort, make_response, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash
from markupsafe import escape


import os
from werkzeug.utils import secure_filename

UPLOAD_FOLDER = os.path.join('static', 'images')
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'}
app = Flask(__name__)
app.secret_key = "secret key"

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/stockform', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        # check if the post request has the file part
        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)
        file = request.files['file']
        # If the user does not select a file, the browser submits an
        # empty file without a filename.
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            return render_template('stocklevel.html',filename=filename)
    return render_template('stockform.html')
#Form for new stock
''''@app.route('/stockform', methods=['GET', 'POST'])  
def stockform():
    if request.method == 'POST':
        return do_the_stockup(request.form['bookname'],       #getting data from forms
                              request.form['authorname'],
                              request.form['isbn'],
                              request.form['desc'],
                              request.form['tpr'],
                              request.form['bquantity'],
                              request.form['rrp'],
                              request.form['date'])
            
    else:
        return show_the_stock_form();
def show_the_stock_form():
    return render_template('stockform.html')


def do_the_stockup(b, a, i, d, t, bq, r, dt):  #Form connecting with database
    con = sqlite3.connect('newstock.db')
    try:
        con.execute('CREATE TABLE newbooks (bookname TEXT, authorname TEXT, isbn INT, desc TEXT, tpr INT, bquantity INT, rrp INT, date DATE)')  #creating table
        print ('Table created successfully');
    except:
        pass
    
    con.close()  
    
    con = sqlite3.connect('newstock.db')
    print ('updating stock')
    con.execute("INSERT INTO newbooks values(?,?,?,?,?,?,?,?);", (b, a, i, d, t, bq, r, dt))  #uploading data to database
    con.commit()
    con.close()  

    return render_template('stockform.html')'''

   
#SIGN UP
@app.route('/register', methods=['GET', 'POST'])  
def register():
    if request.method == 'POST':
        return do_the_registration(request.form['uname'], request.form['pwd'])     #taking data from forms
    else:
        return show_the_registration_form();
def show_the_registration_form():
    return render_template('register.html',page=url_for('register')) #display form

def do_the_registration(u,p):
    con = sqlite3.connect('registered_users.db')
    try:
        con.execute('CREATE TABLE users (name TEXT, pwd INT)')  #creating table and coulumns
        print ('Table created successfully');                   
    except:
        pass
    
    con.close()  
    
    con = sqlite3.connect('registered_users.db')
    con.execute("INSERT INTO users values(?,?);", (u, p))       #insert data in database
    con.commit()
    con.close()  

    return show_the_login_form()                                #directs to log in page

#SIGN IN
@app.route('/login', methods=['GET', 'POST'])   
def login():
    if request.method == 'POST':
        return do_the_login(request.form['uname'], request.form['pwd'])
    else:
        return show_the_login_form()
def show_the_login_form():
    return render_template('login.html',page=url_for('login'))

def do_the_login(u,p):
    con = sqlite3.connect('registered_users.db')
    cur = con.cursor();
    cur.execute("SELECT count(*) FROM users WHERE name=? AND pwd=?;", (u,p))    #checking database for username and password
    if (int(cur.fetchone()[0]))>0:
        return admin(u,p)
    else:
        abort(403)
@app.errorhandler(403)
def wrong_details(error):
    return render_template('wrong_details.html'), 403
def admin(u,p):
    if u == "admin" and p== "p455w0rd":        #verifying admin credentials to return admin page
        return render_template('admin.html')
    else:
        return redirect(url_for('.homepage'))
    
 #CART   
@app.route('/add', methods=['POST'])  
def add_product_to_cart():
    cursor = None
    try:
        _quantity = int(request.form['quantity'])             #storing data from forms
        _code = request.form['code']
        
        if _quantity and _code and request.method == 'POST':
            con = sqlite3.connect('products.db')         #connect to database
            cur = con.cursor();
            cur.execute("SELECT * FROM products WHERE code=?;", [_code])
            row = cur.fetchone()
            itemArray = { row[2] : {'name' : row[1], 'code' : row[2], 'quantity' : _quantity, 'price' : row[4], 'image' : row[3], 'total_price': _quantity * row[4]}}
            print('itemArray is', itemArray)
            
            all_total_price = 0
            all_total_quantity = 0
            
            session.modified = True
            
            if 'cart_item' in session:
                print('in session')
                if row[2] in session['cart_item']:
                    for key, value in session['cart_item'].items():
                        if row[2] == key:
                            old_quantity = session['cart_item'][key]['quantity']
                            total_quantity = old_quantity + _quantity
                            session['cart_item'][key]['quantity'] = total_quantity
                            session['cart_item'][key]['total_price'] = total_quantity * row[4]
                else:
                    session['cart_item'] = array_merge(session['cart_item'], itemArray)
                    
                for key, value in session['cart_item'].items():
                    individual_quantity = int(session['cart_item'][key]['quantity'])
                    individual_price = float(session['cart_item'][key]['total_price'])
                    all_total_quantity = all_total_quantity + individual_quantity
                    all_total_price = all_total_price + individual_price
            else:
                session['cart_item'] = itemArray
                all_total_quantity = all_total_quantity + _quantity
                all_total_price = all_total_price + _quantity * row[4]
                
            session['all_total_quantity'] = all_total_quantity
            session['all_total_price'] = all_total_price
            
            return redirect(url_for('.products'))
        else:
            return 'Error while adding item to cart'
    except Exception as e:
        print(e)
    finally:
        cur.close()
        con.close()
		
#HOMEPAGE        
@app.route('/')
def products():
    try:
        con = sqlite3.connect('products.db')           #connecting database
        cur = con.cursor();
        cur.execute("SELECT * FROM products")
        rows = cur.fetchall()                          #pulling eveything from dataase
        return render_template('homepage.html', products=rows)      #returnn page and assign variable
    except Exception as e:
        print(e)
    finally:
        cur.close()
        con.close()                                     #close connection
@app.route('/stocklevel')
def stock():
    try:
        con = sqlite3.connect('newstock.db')
        cur = con.cursor();
        cur.execute("SELECT * FROM newbooks")
        rows = cur.fetchall()
        return render_template('stocklevel.html', products=rows)
    except Exception as e:
        print(e)
    finally:
        cur.close()
        con.close()
        
@app.route('/empty')
def empty_cart():
	try:
		session.clear()
		return redirect(url_for('.homepage'))
	except Exception as e:
		print(e)

@app.route('/delete/<string:code>')
def delete_product(code):
	try:
		all_total_price = 0
		all_total_quantity = 0
		session.modified = True
		
		for item in session['cart_item'].items():
			if item[0] == code:				
				session['cart_item'].pop(item[0], None)      #pop item
				if 'cart_item' in session:
					for key, value in session['cart_item'].items():
						individual_quantity = int(session['cart_item'][key]['quantity'])
						individual_price = float(session['cart_item'][key]['total_price'])
						all_total_quantity = all_total_quantity + individual_quantity
						all_total_price = all_total_price + individual_price
				break
		
		if all_total_quantity == 0:
			session.clear()
		else:
			session['all_total_quantity'] = all_total_quantity
			session['all_total_price'] = all_total_price
		return redirect(url_for('.homepage'))
	except Exception as e:
		print(e)
		
def array_merge( first_array , second_array ):
	if isinstance( first_array , list ) and isinstance( second_array , list ):
		return first_array + second_array
	elif isinstance( first_array , dict ) and isinstance( second_array , dict ):
		return dict( list( first_array.items() ) + list( second_array.items() ) )
	elif isinstance( first_array , set ) and isinstance( second_array , set ):
		return first_array.union( second_array )
	return False	

#CHECKOUT
@app.route('/checkout')
def pay():
    return render_template('checkout.html')

#CART button
@app.route('/mycart')
def cart():
    return render_template('mycart.html')

#purchase complete screen
@app.route('/ordered')
def order():
    return render_template('ordered.html')

@app.route('/table')
def example():
    con = sqlite3.connect('newstock.db')           #connecting database
    cur = con.cursor();
    cur.execute('SELECT * FROM stock')
    data = cur.fetchall()
    return render_template('table.html', output_data = data)
    cur.close()
    con.close()
    
@app.route('/display/<filename>')
def display_image(filename):
	#print('display_image filename: ' + filename)
	return redirect(url_for('static', filename='stocklevel/' + filename), code=301)


		
if __name__ == "__main__":
    app.run()