from flask import Flask
from flask import render_template
import sqlite3 

con = sqlite3.connect('products.db')

#creating coloumns
con.execute('CREATE TABLE newbooks (bookname TEXT, authorname TEXT, isbn INT, desc TEXT, tpr INT, bquantity INT, rrp INT, date DATE)')

con.close()  