from flask import Flask
from flask import render_template
import sqlite3 

con = sqlite3.connect('products.db')     #connecting database

#creating coloumns
con.execute('CREATE TABLE products(id INT unsigned, name VARCHAR(255), code VARCHAR(255), image TEXT, price DOUBLE)')   

con.close()  
con = sqlite3.connect('products.db')

#inserting data with respect to columns
con.execute('INSERT INTO products(id, name, code, image, price) VALUES(202,"Dune",81,"product-images/dune.jpg",34), (1, "Harry Potter", "AMTR01", "product-images/harry potter.jpg", 20.00),(2, "Mox", "USB02", "product-images/mox.jpg", 16.00),(3, "The Lord of the Rings", "SH03", "product-images/the lord of the rings.jpg", 20.00),(4, "The Midnight Library", "LPN4", "product-images/the midnight library.jpg", 10.00),(5, "The Song of Achilles", "3DCAM01", "product-images/the song of achilles.jpg", 20.00),(6, "The Thursday Murder Club", "MB06", "product-images/The thursday murder club.jpg", 13.00),(7, "Ugly Love", "HD03","product-images/ugly love.jpg", 20.00),(8, "Will Smith", "HD08", "product-images/will smith.jpg", 18.00);')

con.commit()
con.close()  #close connection
