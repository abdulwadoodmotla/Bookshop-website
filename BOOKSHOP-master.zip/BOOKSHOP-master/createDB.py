from flask import Flask
from flask import render_template
import sqlite3

app = Flask(__name__)

@app.route('/customers')
def customers():
    con = sqlite3.connect('database.db')
    try:
        con.execute('CREATE TABLE customers (name TEXT, pw INT')
        print ('Data created');
    except:
        pass
    con.close()
        
                                               